console.log(`Node.js version: ${process.version}`);
console.log(`Current directory: ${__dirname}`);
console.log(`Current file: ${__filename}`);

const intervalId = setInterval(() => {
  console.log("Welcome to Node.js!");
}, 3000);

setTimeout(() => {
  clearInterval(intervalId);
  console.log("Timer stopped after 10 seconds.");
}, 10000);