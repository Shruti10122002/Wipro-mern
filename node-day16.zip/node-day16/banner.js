// banner.js - Fixed for chalk v5+ (ESM)

(async () => {
  try {
    // Dynamic import for ESM packages
    const { default: chalk } = await import('chalk');
    const figlet = require('figlet'); // figlet is still CommonJS

    figlet('Welcome to Node.js', (err, data) => {
      if (err) {
        console.log('Figlet error:', err);
        return;
      }
      console.log(chalk.cyan(data));
    });
  } catch (error) {
    console.error('Failed to load chalk:', error);
  }
})();